/**
 * Created by jacek on 29.11.17.
 */
public interface IMethod {

    boolean guard();
    void call();

}
